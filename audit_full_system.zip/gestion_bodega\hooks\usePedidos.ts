export function usePedidos() {
  return { data: null as any, isLoading: false, error: null as any };
}

