import React from 'react';

const ReporteSemanalTables: React.FC = () => {
  return <div>ReporteSemanalTables</div>;
};

export default ReporteSemanalTables;

