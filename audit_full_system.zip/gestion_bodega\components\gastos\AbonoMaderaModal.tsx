import React from 'react';

const AbonoMaderaModal: React.FC = () => {
  return <div>AbonoMaderaModal</div>;
};

export default AbonoMaderaModal;

