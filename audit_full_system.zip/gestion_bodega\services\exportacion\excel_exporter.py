"""Exportación Excel para reportes de bodega - placeholder.

Sugerencia: reusar estructura de gestion_huerta/services/exportacion/excel_exporter.py.
"""

