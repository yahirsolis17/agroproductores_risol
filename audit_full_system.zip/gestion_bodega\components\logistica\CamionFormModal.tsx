import React from 'react';

const CamionFormModal: React.FC = () => {
  return <div>CamionFormModal</div>;
};

export default CamionFormModal;

