import React from 'react';

const InventarioPlasticoTable: React.FC = () => {
  return <div>InventarioPlasticoTable</div>;
};

export default InventarioPlasticoTable;

