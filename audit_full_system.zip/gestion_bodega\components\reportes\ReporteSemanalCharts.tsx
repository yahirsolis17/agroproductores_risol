import React from 'react';

const ReporteSemanalCharts: React.FC = () => {
  return <div>ReporteSemanalCharts</div>;
};

export default ReporteSemanalCharts;

