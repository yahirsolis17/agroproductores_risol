export function useGastos() {
  return { data: null as any, isLoading: false, error: null as any };
}

