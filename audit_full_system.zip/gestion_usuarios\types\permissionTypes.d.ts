// src/modules/gestion_usuarios/types/permissionTypes.d.ts
export interface Permission {
    id: number;
    name: string;
    codename: string;
    content_type: string;
  }
  