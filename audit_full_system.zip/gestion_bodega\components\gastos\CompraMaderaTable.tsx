import React from 'react';

const CompraMaderaTable: React.FC = () => {
  return <div>CompraMaderaTable</div>;
};

export default CompraMaderaTable;

