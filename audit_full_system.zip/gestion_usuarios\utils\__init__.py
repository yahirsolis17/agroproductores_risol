from .activity import registrar_actividad
