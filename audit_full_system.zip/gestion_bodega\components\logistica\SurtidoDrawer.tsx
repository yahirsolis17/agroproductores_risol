import React from 'react';

const SurtidoDrawer: React.FC = () => {
  return <div>SurtidoDrawer</div>;
};

export default SurtidoDrawer;

