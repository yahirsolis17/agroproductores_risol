import React from 'react';

const ReportesTabs: React.FC = () => {
  return <div>ReportesTabs</div>;
};

export default ReportesTabs;

