import React from 'react';

const ConsumibleFormModal: React.FC = () => {
  return <div>ConsumibleFormModal</div>;
};

export default ConsumibleFormModal;

