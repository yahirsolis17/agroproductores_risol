import React from 'react';

const CamionTable: React.FC = () => {
  return <div>CamionTable</div>;
};

export default CamionTable;

