export interface ReporteSemanal {
  iso_semana: string;
  resumen?: Record<string, any>;
}

export interface ReporteTemporada {
  temporada: number;
  resumen?: Record<string, any>;
}

