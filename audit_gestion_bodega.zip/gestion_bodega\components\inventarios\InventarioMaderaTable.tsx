import React from 'react';

const InventarioMaderaTable: React.FC = () => {
  return <div>InventarioMaderaTable</div>;
};

export default InventarioMaderaTable;

