import React from 'react';

const PedidoTable: React.FC = () => {
  return <div>PedidoTable</div>;
};

export default PedidoTable;

