import React from 'react';

const PedidoToolbar: React.FC = () => {
  return <div>PedidoToolbar</div>;
};

export default PedidoToolbar;

