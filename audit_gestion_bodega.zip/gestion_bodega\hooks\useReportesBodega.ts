export function useReportesBodega() {
  return { data: null as any, isLoading: false, error: null as any };
}

