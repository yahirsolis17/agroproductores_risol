import React from 'react';

const ReporteTemporadaViewer: React.FC = () => {
  return <div>ReporteTemporadaViewer</div>;
};

export default ReporteTemporadaViewer;

