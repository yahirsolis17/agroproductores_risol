import React from 'react';

const Reportes: React.FC = () => {
  return <div>Reportes</div>;
};

export default Reportes;

