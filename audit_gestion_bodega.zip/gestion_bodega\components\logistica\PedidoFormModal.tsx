import React from 'react';

const PedidoFormModal: React.FC = () => {
  return <div>PedidoFormModal</div>;
};

export default PedidoFormModal;

