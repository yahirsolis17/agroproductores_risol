import React from 'react';

const CompraMaderaFormModal: React.FC = () => {
  return <div>CompraMaderaFormModal</div>;
};

export default CompraMaderaFormModal;

