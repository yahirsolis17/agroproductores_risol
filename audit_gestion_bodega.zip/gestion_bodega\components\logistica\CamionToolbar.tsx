import React from 'react';

const CamionToolbar: React.FC = () => {
  return <div>CamionToolbar</div>;
};

export default CamionToolbar;

