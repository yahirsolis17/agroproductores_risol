"""Exportación PDF para reportes de bodega - placeholder.

Sugerencia: reusar estructura de gestion_huerta/services/exportacion/pdf_exporter.py.
"""

