import React from 'react';

const AjusteInventarioModal: React.FC = () => {
  return <div>AjusteInventarioModal</div>;
};

export default AjusteInventarioModal;

