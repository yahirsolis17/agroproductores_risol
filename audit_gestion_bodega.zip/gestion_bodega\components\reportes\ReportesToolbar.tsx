import React from 'react';

const ReportesToolbar: React.FC = () => {
  return <div>ReportesToolbar</div>;
};

export default ReportesToolbar;

