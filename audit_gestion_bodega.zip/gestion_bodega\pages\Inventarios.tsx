import React from 'react';

const Inventarios: React.FC = () => {
  return <div>Inventarios</div>;
};

export default Inventarios;

