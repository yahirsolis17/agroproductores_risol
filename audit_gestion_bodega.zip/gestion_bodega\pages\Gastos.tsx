import React from 'react';

const Gastos: React.FC = () => {
  return <div>Gastos</div>;
};

export default Gastos;

