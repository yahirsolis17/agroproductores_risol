import React from 'react';

const GastosToolbar: React.FC = () => {
  return <div>GastosToolbar</div>;
};

export default GastosToolbar;

