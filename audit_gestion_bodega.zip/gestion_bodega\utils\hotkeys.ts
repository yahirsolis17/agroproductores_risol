export function registerHotkeys() {
  // TODO: implement hotkeys for fast capture
}

