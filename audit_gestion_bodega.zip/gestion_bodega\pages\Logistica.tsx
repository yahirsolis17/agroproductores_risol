import React from 'react';

const Logistica: React.FC = () => {
  return <div>Logistica</div>;
};

export default Logistica;

