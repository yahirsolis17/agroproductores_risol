export function useTiposMango() {
  return { data: [] as string[], isLoading: false, error: null as any };
}

