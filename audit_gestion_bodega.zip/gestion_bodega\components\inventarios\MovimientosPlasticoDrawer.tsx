import React from 'react';

const MovimientosPlasticoDrawer: React.FC = () => {
  return <div>MovimientosPlasticoDrawer</div>;
};

export default MovimientosPlasticoDrawer;

