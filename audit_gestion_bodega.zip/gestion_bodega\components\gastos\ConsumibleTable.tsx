import React from 'react';

const ConsumibleTable: React.FC = () => {
  return <div>ConsumibleTable</div>;
};

export default ConsumibleTable;

