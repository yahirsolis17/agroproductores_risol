import React from 'react';

const InventariosTabs: React.FC = () => {
  return <div>InventariosTabs</div>;
};

export default InventariosTabs;

