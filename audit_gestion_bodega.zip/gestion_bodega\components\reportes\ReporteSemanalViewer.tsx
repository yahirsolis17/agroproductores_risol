import React from 'react';

const ReporteSemanalViewer: React.FC = () => {
  return <div>ReporteSemanalViewer</div>;
};

export default ReporteSemanalViewer;

