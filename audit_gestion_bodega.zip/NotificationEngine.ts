import { toast } from 'react-toastify';

// Debounce para evitar notificaciones duplicadas (especialmente en dev con StrictMode)
let _lastNotif: { key?: string; message?: string; ts: number } | null = null;
const NOTIF_DEDUP_WINDOW_MS = 1000; // 1s

function shouldSuppressDuplicate(key?: string, message?: string) {
  const now = Date.now();
  if (_lastNotif && now - _lastNotif.ts < NOTIF_DEDUP_WINDOW_MS) {
    if (_lastNotif.key === key && _lastNotif.message === message) {
      return true;
    }
  }
  _lastNotif = { key, message, ts: now };
  return false;
}

const SILENT_NOTIFICATION_KEYS = ['no_notification', 'silent_response', 'data_processed_success'];

// ⛔ Claves que NO deben provocar redirect automático
const REDIRECT_BLOCKLIST = new Set(['login_success', 'password_change_success']);

const KEY_TO_TYPE: Record<string, 'success' | 'error' | 'warning' | 'info'> = {
  permission_denied: 'error',
  validation_error: 'warning',
  server_error: 'error',
  data_processed_success: 'info',
  login_success: 'success',
  password_change_success: 'success',
  reporte_generado_exitosamente: 'success',
  export_requires_view: 'error',
  export_denied_no_view: 'error',
  export_denied_no_export: 'error',
};

export function handleBackendNotification(response: any) {
  const notif = response?.notification;
  if (!notif) return;

  let { type, message = 'Operación completada.', key, action, target } = notif;
  if (!type && key && KEY_TO_TYPE[key]) {
    type = KEY_TO_TYPE[key];
  }

  // Notificaciones silenciosas (no toast)
  if (key && SILENT_NOTIFICATION_KEYS.includes(key)) {
    // Aun si es silenciosa, respetamos redirect salvo que esté bloqueado
    if (
      action === 'redirect' &&
      typeof target === 'string' &&
      target &&
      !REDIRECT_BLOCKLIST.has(key || '')
    ) {
      window.location.assign(target);
    }
    return;
  }

  // Debounce duplicados recientes
  if (shouldSuppressDuplicate(key, message)) return;

  // Toasts
  switch (type) {
    case 'success':
      toast.success(message);
      break;
    case 'error':
      toast.error(message);
      break;
    case 'warning':
      toast.warning(message);
      break;
    case 'info':
    default:
      toast.info(message);
  }

  // Redirect si aplica y NO está bloqueado por política
  if (
    action === 'redirect' &&
    typeof target === 'string' &&
    target &&
    !REDIRECT_BLOCKLIST.has(key || '')
  ) {
    window.location.assign(target);
  }

  if (import.meta.env.DEV) {
    console.log(`[Notificación: ${key}]`, message, action ? `action=${action}` : '');
  }
}
export default { handleBackendNotification };
