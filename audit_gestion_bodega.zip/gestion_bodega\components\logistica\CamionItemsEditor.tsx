import React from 'react';

const CamionItemsEditor: React.FC = () => {
  return <div>CamionItemsEditor</div>;
};

export default CamionItemsEditor;

