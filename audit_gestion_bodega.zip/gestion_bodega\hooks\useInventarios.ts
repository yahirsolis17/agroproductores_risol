export function useInventarios() {
  return { data: null as any, isLoading: false, error: null as any };
}

